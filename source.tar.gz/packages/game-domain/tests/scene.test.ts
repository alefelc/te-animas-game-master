import { describe, expect, it } from "vitest";
import {
  advanceSceneState,
  candidateInvariantReasons,
  checkSceneCompatibility,
  initialSceneState,
  plannedScenePhase,
  scoreSceneCandidate,
  type SceneCandidate,
} from "../src/index.js";

const base: SceneCandidate = {
  id: "card-1",
  intensity: 2,
  card_kind: "transition",
  scene_phase_min: "connection",
  scene_phase_max: "contact",
  scene_phase_after: "contact",
  physical_state_min: "clothed",
  physical_state_after: "suggestive",
  activity_family: "kissing",
  activity_action: "start",
  requires_previous_activity: null,
  forbidden_after_activity: null,
  allow_activity_change: true,
  allow_position_change: true,
  allow_rhythm_change: true,
  inventory_action: "none",
  inventory_keys: [],
  gm_continuity_group: "kissing",
  gm_escalation_score: 1,
  gm_recovery_score: 0,
  gm_novelty_score: 3,
  variant_group: "kiss-1",
  cooldown_sessions: 2,
};

describe("scene domain", () => {
  it("blocks actions that require a later physical state", () => {
    const result = checkSceneCompatibility(initialSceneState(), {
      ...base,
      physical_state_min: "nude",
      physical_state_after: "nude",
    });
    expect(result.compatible).toBe(false);
    expect(result.reasons).toContain("physical_state_too_early");
  });

  it("advances the scene and keeps continuity counters", () => {
    const state = advanceSceneState(initialSceneState(), base);
    expect(state.phase).toBe("contact");
    expect(state.active_activity).toBe("kissing");
    expect(state.last_continuity_group).toBe("kissing");
    expect(state.activity_streak).toBe(1);
    expect(state.cards_in_phase).toBe(1);
  });

  it("does not allow continue, intensify or switch without an active activity", () => {
    for (const action of ["continue", "intensify", "switch"] as const) {
      const result = checkSceneCompatibility(initialSceneState(), {
        ...base,
        activity_action: action,
      });
      expect(result.compatible).toBe(false);
      expect(result.reasons).toContain(
        action === "switch" ? "activity_switch_without_active" : "active_activity_missing",
      );
    }
  });

  it("does not allow a closing card before climax", () => {
    const result = checkSceneCompatibility(
      {
        ...initialSceneState(),
        phase: "action",
        physical_state: "sexual_activity",
        active_activity: "oral",
      },
      {
        ...base,
        card_kind: "closure",
        scene_phase_min: "action",
        scene_phase_max: "closure",
        scene_phase_after: "closure",
        physical_state_min: "sexual_activity",
        physical_state_after: "aftercare",
        activity_action: "complete",
        activity_family: "oral",
      },
    );
    expect(result.compatible).toBe(false);
    expect(result.reasons).toContain("closure_before_climax");
  });

  it("allows a closing card after climax", () => {
    const result = checkSceneCompatibility(
      {
        ...initialSceneState(),
        phase: "climax",
        physical_state: "climax",
        climax_reached: true,
        active_activity: "oral",
      },
      {
        ...base,
        card_kind: "closure",
        scene_phase_min: "action",
        scene_phase_max: "closure",
        scene_phase_after: "closure",
        physical_state_min: "sexual_activity",
        physical_state_after: "aftercare",
        activity_action: "complete",
        activity_family: "touching",
        allow_activity_change: true,
      },
    );
    expect(result.compatible).toBe(true);
  });

  it("requires all resources for inventory continuation", () => {
    const result = checkSceneCompatibility(
      {
        ...initialSceneState(),
        inventory_in_scene: ["toy:vibrador"],
      },
      {
        ...base,
        activity_action: "none",
        activity_family: null,
        inventory_action: "continue",
        inventory_keys: ["toy:vibrador", "element:lubricante"],
      },
    );
    expect(result.compatible).toBe(false);
    expect(result.reasons).toContain("inventory_not_in_scene");
  });

  it("strongly rewards continuation of an active activity", () => {
    const state = advanceSceneState(initialSceneState(), base);
    const continuation = {
      ...base,
      id: "continue",
      card_kind: "continuity" as const,
      scene_phase_min: "contact" as const,
      scene_phase_after: "contact" as const,
      activity_action: "continue" as const,
      allow_activity_change: false,
    };
    const switcher = {
      ...continuation,
      id: "switch",
      activity_family: "touching",
      activity_action: "switch" as const,
      allow_activity_change: true,
    };
    expect(
      scoreSceneCandidate(state, continuation, { progress: 0.3, targetIntensity: 5 }),
    ).toBeGreaterThan(
      scoreSceneCandidate(state, switcher, { progress: 0.3, targetIntensity: 5 }),
    );
  });

  it("uses a deliberate phase plan and only closes after climax", () => {
    expect(plannedScenePhase(0)).toBe("connection");
    expect(plannedScenePhase(0.5)).toBe("nudity");
    expect(plannedScenePhase(0.95)).toBe("climax");
    expect(plannedScenePhase(0.4, { ...initialSceneState(), climax_reached: true })).toBe("closure");
  });

  it("rejects contradictory card metadata", () => {
    expect(
      candidateInvariantReasons({
        ...base,
        scene_phase_min: "action",
        scene_phase_max: "contact",
      }),
    ).toContain("invalid_phase_window");
  });
});
