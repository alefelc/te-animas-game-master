import { describe, expect, it } from "vitest";
import {
  NextRequestSchema,
  NextResponseSchema,
  normalizeSceneRole,
} from "../src/index.js";

describe("canonical adaptive contract", () => {
  it("normalizes legacy scene roles before validation", () => {
    const parsed = NextRequestSchema.parse({
      game_id: "game",
      session_id: "session",
      mode_id: "mode",
      candidates: [{ id: "1", code: "C1", text: "Carta", gm_scene_role: "escalada" }],
    });
    expect(parsed.candidates[0]?.gm_scene_role).toBe("bridge");
  });

  it("accepts the exact response consumed by the frontend", () => {
    const response = NextResponseSchema.parse({
      selected_card_id: "1",
      phase: "build",
      strategy: "continue_scene",
      target_tension: 40,
      target_energy: 45,
      host_message: "Sigan con esta energía.",
      confidence: 0.8,
      provider: "adaptive_fallback",
      model: "deterministic",
      latency_ms: 3,
      fallback_used: true,
    });
    expect(response.request_id).toBeNull();
  });

  it("keeps scene-role normalization deterministic", () => {
    expect(normalizeSceneRole("opening")).toBe("starter");
    expect(normalizeSceneRole("aftercare")).toBe("recovery");
  });
});
